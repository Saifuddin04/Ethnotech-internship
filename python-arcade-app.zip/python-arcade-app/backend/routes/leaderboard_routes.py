from flask import Blueprint, jsonify
from database.db import mongo

leaderboard_bp = Blueprint("leaderboard", __name__)


@leaderboard_bp.route("/leaderboard")
def leaderboard():

    players = list(
        mongo.db.users.find({}, {"_id": 0})
        .sort("total_score", -1)
        .limit(10)
    )

    return jsonify(players)