from flask import Blueprint, request, jsonify
from games.number_guessing import check_guess
from games.quiz_game import get_questions, check_answer
from games.tic_tac_toe import make_move, check_winner, get_board
from games.tic_tac_toe import ai_move

game_bp = Blueprint("game", __name__)


@game_bp.route("/guess", methods=["POST"])
def guess():

    guess = int(request.json["guess"])

    result = check_guess(guess)

    return jsonify({"result": result})

@game_bp.route("/quiz/questions", methods=["GET"])
def quiz_questions():

    questions = get_questions()

    for q in questions:
        q.pop("answer")

    return jsonify(questions)


@game_bp.route("/quiz/answer", methods=["POST"])
def quiz_answer():

    data = request.json

    question_index = data["question_index"]
    answer = data["answer"]

    correct = check_answer(question_index, answer)

    return jsonify({"correct": correct})

@game_bp.route("/tictactoe/move", methods=["POST"])
def tictactoe_move():

    data = request.json

    position = data["position"]
    player = data["player"]

    make_move(position, player)

    winner = check_winner()

    if not winner:
        ai_position = ai_move()
        winner = check_winner()
    else:
        ai_position = None

    return jsonify({
        "board": get_board(),
        "ai_move": ai_position,
        "winner": winner
    })
@game_bp.route("/tictactoe/reset", methods=["POST"])
def reset():

    from games.tic_tac_toe import reset_board

    reset_board()

    return jsonify({"status": "reset"})

