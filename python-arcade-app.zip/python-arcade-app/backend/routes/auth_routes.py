from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token

from models.user_model import create_user, find_user
from utils.auth_helper import hash_password, verify_password

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/register", methods=["POST"])
def register():

    data = request.json

    username = data["username"]
    password = data["password"]

    hashed = hash_password(password)

    create_user(username, hashed)

    return jsonify({"message": "User registered"})


@auth_bp.route("/login", methods=["POST"])
def login():

    data = request.json

    user = find_user(data["username"])

    if user and verify_password(data["password"], user["password"]):

        token = create_access_token(identity=data["username"])

        return jsonify({"token": token})

    return jsonify({"error": "Invalid credentials"}), 401