from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from flask_jwt_extended import JWTManager
import os

from config import Config
from database.db import init_db

from routes.auth_routes import auth_bp
from routes.game_routes import game_bp
from routes.leaderboard_routes import leaderboard_bp


def create_app():

    app = Flask(
        __name__,
        static_folder="../frontend",
        template_folder="../frontend"
    )

    # Load config
    app.config.from_object(Config)

    # Enable CORS
    CORS(app)

    # Initialize JWT
    JWTManager(app)

    # Initialize MongoDB
    init_db(app)

    # Register API blueprints
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(game_bp, url_prefix="/game")
    app.register_blueprint(leaderboard_bp, url_prefix="/leaderboard")

    # Path to frontend folder
    FRONTEND_PATH = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "frontend")
    )

    # Dashboard page
    @app.route("/")
    def dashboard():
        return app.send_static_file("dashboard.html")

    @app.route("/login")
    def login_page():
        return app.send_static_file("login.html")

    @app.route("/home")
    def home_page():
        return app.send_static_file("index.html")
    
    # Serve frontend JS/CSS
    @app.route("/static/<path:path>")
    def static_files(path):
        return send_from_directory(FRONTEND_PATH, path)

    # Serve assets
    ASSETS_PATH = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "assets")
    )

    @app.route("/assets/<path:path>")
    def assets(path):
        return send_from_directory(ASSETS_PATH, path)

    # Health check API
    @app.route("/api")
    def api_status():
        return jsonify({
            "message": "Python Arcade API Running 🚀",
            "routes": {
                "register": "/auth/register",
                "login": "/auth/login",
                "games": "/game",
                "leaderboard": "/leaderboard"
            }
        })

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)