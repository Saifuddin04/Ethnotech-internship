questions = [
    {
        "question": "What is the capital of France?",
        "options": ["Paris", "London", "Berlin", "Rome"],
        "answer": "Paris"
    },
    {
        "question": "Which language is used for web apps?",
        "options": ["Python", "JavaScript", "C++", "Java"],
        "answer": "JavaScript"
    },
    {
        "question": "Which company created Python?",
        "options": ["Google", "Microsoft", "Python Software Foundation", "IBM"],
        "answer": "Python Software Foundation"
    }
]


def get_questions():
    return questions


def check_answer(question_index, user_answer):

    correct_answer = questions[question_index]["answer"]

    return user_answer == correct_answer