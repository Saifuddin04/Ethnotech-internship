import random

secret_number = random.randint(1, 100)

def check_guess(guess):
    global secret_number

    if guess > secret_number:
        return "lower"

    if guess < secret_number:
        return "higher"

    secret_number = random.randint(1, 100)

    return "correct"