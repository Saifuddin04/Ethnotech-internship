board = [""] * 9


def reset_board():
    global board
    board = [""] * 9


def make_move(position, player):

    if board[position] == "":
        board[position] = player
        return True

    return False


def check_winner():

    wins = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]

    for a,b,c in wins:

        if board[a] == board[b] == board[c] and board[a] != "":
            return board[a]

    if "" not in board:
        return "draw"

    return None


def get_board():
    return board


def ai_move():

    for i in range(9):
        if board[i] == "":
            board[i] = "O"
            return i

    return None