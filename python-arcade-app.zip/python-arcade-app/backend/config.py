import os

class Config:

    SECRET_KEY = "arcade-secret"

    JWT_SECRET_KEY = "jwt-secret-key"

    MONGO_URI = "mongodb+srv://hassansf176_db_user:<db_password>@cluster0.ucmama8.mongodb.net/?appName=Cluster0"