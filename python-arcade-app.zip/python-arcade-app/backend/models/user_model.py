from database.db import mongo


def create_user(username, password):

    user = {
        "username": username,
        "password": password,
        "total_score": 0,
        "games_played": 0
    }

    mongo.db.users.insert_one(user)


def find_user(username):

    return mongo.db.users.find_one({"username": username})