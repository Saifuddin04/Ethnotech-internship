from database.db import mongo


def add_score(username, game, score):

    mongo.db.scores.insert_one({
        "username": username,
        "game": game,
        "score": score
    })

    mongo.db.users.update_one(
        {"username": username},
        {"$inc": {"total_score": score, "games_played": 1}}
    )