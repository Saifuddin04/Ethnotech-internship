async function loadLeaderboard(){

let res=await fetch("http://127.0.0.1:5000/leaderboard")

let players=await res.json()

let list="Leaderboard\n\n"

players.forEach(p=>{

list+=p.username+" : "+p.total_score+"\n"

})

alert(list)

}