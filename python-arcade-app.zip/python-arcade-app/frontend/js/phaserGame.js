const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: "game",
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

function preload(){
}

function create(){

this.add.text(250,100,"Python Arcade",{
fontSize:"40px",
color:"#ffffff"
});

this.add.text(300,250,"Start Game",{
fontSize:"28px",
backgroundColor:"#000",
padding:10
}).setInteractive().on("pointerdown",()=>{

alert("Game menu coming soon")

});

}

function update(){
}

function preload(){

this.load.audio("click","../assets/sounds/click.mp3")

}

function create(){

let sound=this.sound.add("click")

this.input.on("pointerdown",()=>{
sound.play()
})

}