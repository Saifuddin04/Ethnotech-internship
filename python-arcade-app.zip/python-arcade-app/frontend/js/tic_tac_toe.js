let boardDiv=document.getElementById("board")

for(let i=0;i<9;i++){

let cell=document.createElement("button")

cell.innerText="-"

cell.onclick=()=>move(i)

boardDiv.appendChild(cell)

}

async function move(pos){

let res=await fetch("http://127.0.0.1:5000/tictactoe/move",{

method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({position:pos,player:"X"})

})

let data=await res.json()

console.log(data)

}