async function sendGuess(){

let guess=document.getElementById("guessInput").value

let res=await fetch("http://127.0.0.1:5000/guess",{

method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({guess:guess})

})

let data=await res.json()

alert(data.result)

}