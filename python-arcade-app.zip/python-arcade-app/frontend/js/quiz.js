async function loadQuiz(){

let res=await fetch("http://127.0.0.1:5000/quiz/questions")

let questions=await res.json()

console.log(questions)

}